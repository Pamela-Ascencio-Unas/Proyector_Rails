class Editorial < ApplicationRecord
  has_many :books
end
